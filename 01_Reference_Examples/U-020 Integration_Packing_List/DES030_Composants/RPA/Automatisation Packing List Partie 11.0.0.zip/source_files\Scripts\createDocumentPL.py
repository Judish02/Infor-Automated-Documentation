import sys
import os
import json
import re

if len(sys.argv) < 4:
    print("Usage: python createDocument.py <json_file_path> <output_dir> <document_path>")
    sys.exit(1)

json_file_path = sys.argv[1]
output_dir = sys.argv[2]
document_path = sys.argv[3]

if not os.path.isfile(json_file_path):
    print(f"Error: JSON file does not exist: {json_file_path}")
    sys.exit(1)

if not os.path.isdir(output_dir):
    print(f"Error: Output directory does not exist: {output_dir}")
    sys.exit(1)

document_name = os.path.basename(document_path)

try:
    with open(json_file_path, "r", encoding="utf-8") as f:
        input_json = json.load(f)

    extraction_data = input_json.get("ExtractionData", [])
    table_data_input = input_json.get("TableDetection", [])

    def get_field(field_list, name):
        for f in field_list:
            if f.get("FieldName") == name:
                return f.get("FieldValue")
        return None

    supplier_number = get_field(extraction_data, "Supplier Number") or ""
    container_number = get_field(extraction_data, "Container Number") or ""

    idm_document_id = f"{supplier_number}_{container_number}".replace("/", "_")

    field_mapping = {
        "Supplier Number": "supplier_number",
        "Container Number": "container_number"
    }

    document_entities = []
    for source, target in field_mapping.items():
        value = get_field(extraction_data, source)
        if value not in (None, ""):
            document_entities.append({
                "key": target,
                "value": value
            })

    table_data_output = []
    for table in table_data_input:
        table_name = table.get("TableName", "").lower()
        rows = table.get("TableRows", [])

        if table_name == "lignes":
            line_rows = []
            for row in rows:
                one_row = []
                for col in row:
                    col_name = col.get("ColumnName", "")
                    val = col.get("OCR_text", "").strip()

                    if col_name == "PI NO":
                        key_name = "numero_oa"
                    elif col_name == "Item Number":
                        key_name = "item_number"
                    elif col_name == "Total CBM":
                        key_name = "volume_cbm"
                    elif col_name == "Total Gross Weight":
                        key_name = "poid_brut"
                    else:
                        continue

                    one_row.append({"key": key_name, "value": val})

                if one_row:
                    line_rows.append({"row": one_row})

            table_data_output.append({
                "name": "Lignes",
                "rows": line_rows
            })

    result = {
        "reprocess": False,
        "visibility": True,
        "document_name": document_name,
        "category_key": "Informations_extraites",
        "idm_document_id": idm_document_id,
        "document_entities": document_entities,
        "table_data": table_data_output,
        "document_users": []
    }

    output_path = os.path.join(output_dir, "review_center_document.json")

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=4)

    print(f"JSON document successfully created: {output_path}")

except Exception as e:
    print(f"Unexpected error: {e}")
    sys.exit(1)