import os
import sys

file_path = sys.argv[1]

# Check if file exists
if not os.path.isfile(file_path):
    print(f"Error: File '{file_path}' does not exist.")
    sys.exit(1)

# Get file size and convert to MB
file_size = os.path.getsize(file_path)
file_size_mb = file_size / (1024 * 1024)

if file_size_mb > 0.001:
    print("T")
else:
    print("F")

