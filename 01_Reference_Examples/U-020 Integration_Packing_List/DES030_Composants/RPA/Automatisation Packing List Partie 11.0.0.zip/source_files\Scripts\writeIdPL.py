import sys
import os
import json
from datetime import datetime, timedelta

if len(sys.argv) < 2:
    print("Usage: python create_id_file.py <string_value>")
    sys.exit(1)

input_value = sys.argv[1]
output_dir = sys.argv[2]

if not os.path.isdir(output_dir):
    os.makedirs(output_dir)

try:
    file_path = os.path.join(output_dir, f"{input_value}.txt")

    with open(file_path, "w", encoding="utf-8") as f_out:
        f_out.write(input_value)

    print(f"File created: {file_path}")

except Exception as e:
    print(f"Unexpected error: {e}")
    sys.exit(1)
