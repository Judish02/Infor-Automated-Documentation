import sys
import os
import win32com.client

# Arguments
input_dir = sys.argv[1]
output_dir = sys.argv[2]
packing_list_path = sys.argv[3]

os.makedirs(output_dir, exist_ok=True)
os.makedirs(packing_list_path, exist_ok=True)

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = False
excel.DisplayAlerts = False

try:
    for file in os.listdir(input_dir):
        if file.lower().endswith((".xlsx", ".xls")):
            excel_path = os.path.join(input_dir, file)

            base_name = os.path.splitext(file)[0].replace(" ", "")

            wb = excel.Workbooks.Open(excel_path)

            try:
                for idx in range(2, wb.Sheets.Count + 1):
                    sheet = wb.Sheets(idx)

                    sheet.PageSetup.Zoom = False
                    sheet.PageSetup.FitToPagesWide = 1
                    sheet.PageSetup.FitToPagesTall = 1

                    raw_sheet_name = sheet.Name.strip().replace(" ", "")

                    safe_sheet_name = "".join(
                        c if c.isalnum() or c in "-_"
                        else "_"
                        for c in raw_sheet_name
                    ).rstrip("_")

                    pdf_name = f"{base_name}_{safe_sheet_name}.pdf"
                    pdf_path = os.path.join(packing_list_path, pdf_name)

                    print(f"  Exporting packing list '{sheet.Name}' -> {pdf_path}")
                    sheet.ExportAsFixedFormat(0, pdf_path)

                print(f"Finished processing file: {file}")

            except Exception as e:
                print(f"Error converting {file}: {e}")
            finally:
                wb.Close(False)

finally:
    excel.Quit()