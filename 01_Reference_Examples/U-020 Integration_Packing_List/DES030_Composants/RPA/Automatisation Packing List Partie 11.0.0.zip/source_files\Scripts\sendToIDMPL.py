import sys
import os
import json
import base64
import random
import re

if len(sys.argv) != 4:
    print("Usage: python build_payload.py <pdf_path> <json_path> <output_dir>")
    sys.exit(1)

pdf_path = sys.argv[1]
json_path = sys.argv[2]
output_dir = sys.argv[3]

if not os.path.isfile(pdf_path):
    print(f"Error: PDF file does not exist: {pdf_path}")
    sys.exit(1)

if not os.path.isfile(json_path):
    print(f"Error: JSON file does not exist: {json_path}")
    sys.exit(1)

os.makedirs(output_dir, exist_ok=True)

with open(pdf_path, "rb") as pdf_file:
    pdf_bytes = pdf_file.read()
    pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")

with open(json_path, "r", encoding="utf-8") as f:
    data = json.load(f)

supplier_number = None
container_number = None

for field in data.get("ExtractionData", []):
    field_name = field.get("FieldName", "").strip()
    if field_name == "Supplier Number":
        supplier_number = field.get("FieldValue", "").strip()
    elif field_name == "Container Number":
        container_number = field.get("FieldValue", "").strip()

if not supplier_number or not container_number:
    print("Error: Could not find Supplier Number or Container Number in JSON.")
    sys.exit(1)

ID = f"{supplier_number}_{container_number}"

def sanitize_name(name):
    return re.sub(r'[<>:"/\\|?*]', "_", name)

ID_sanitized = sanitize_name(ID)

filename = os.path.basename(pdf_path)

pid = str(random.randint(1000000000, 9999999999))

payload = {
    "item": {
        "attrs": {
            "attr": [
                {
                    "name": "ID",
                    "value": ID_sanitized
                }
            ]
        },
        "resrs": {
            "res": {
                "filename": filename,
                "base64": pdf_base64
            }
        },
        "acl": {
            "name": "Public"
        },
        "entityName": "RPAReviewCenter",
        "pid": pid
    }
}

output_file = os.path.join(output_dir, f"{ID_sanitized}.txt")
with open(output_file, "w", encoding="utf-8") as out_f:
    json.dump(payload, out_f, indent=2)

print(f"Payload successfully written to {output_file}")