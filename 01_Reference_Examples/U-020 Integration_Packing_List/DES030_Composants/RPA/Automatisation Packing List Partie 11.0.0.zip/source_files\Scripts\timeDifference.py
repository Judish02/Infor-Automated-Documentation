import sys
import os
import json
from datetime import datetime, timedelta

if len(sys.argv) < 3:
    sys.exit(1)

input_value1 = sys.argv[1]
input_value2 = sys.argv[2]

try:
    dt1 = datetime.strptime(input_value1, "%Y%m%d_%H%M%S")
    dt2 = datetime.strptime(input_value2, "%Y%m%d_%H%M%S")

    if dt2 >= dt1 + timedelta(minutes=15):
        sys.stdout.write("Y")
    else:
        sys.stdout.write("N")

except Exception:
    sys.exit(1)