import sys
import os
import json
from datetime import datetime, timedelta
import shutil

if len(sys.argv) < 4:
    print("Usage: python check_and_move_file.py <id_text_file> <json_file> <destination_dir>")
    sys.exit(1)

id_file_path = sys.argv[1]
json_file_path = sys.argv[2]
destination_dir = sys.argv[3]

if not os.path.isfile(id_file_path):
    print(f"ID file not found: {id_file_path}")
    sys.exit(1)

if not os.path.isfile(json_file_path):
    print(f"JSON file not found: {json_file_path}")
    sys.exit(1)

if not os.path.isdir(destination_dir):
    os.makedirs(destination_dir)

try:
    with open(id_file_path, "r", encoding="utf-8") as f:
        file_id = f.read().strip()

    with open(json_file_path, "r", encoding="utf-8") as jf:
        json_data = json.load(jf)

    items = json_data.get("items", [])
    json_ids = {item.get("id") for item in items if "id" in item}

    if file_id in json_ids:
        print(f"ID '{file_id}' found in JSON. No action taken.")
    else:
        destination_path = os.path.join(destination_dir, os.path.basename(id_file_path))
        shutil.move(id_file_path, destination_path)
        print(f"ID '{file_id}' not found. File moved to: {destination_path}")

except Exception as e:
    print(f"Unexpected error: {e}")
    sys.exit(1)